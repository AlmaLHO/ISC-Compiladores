package capturatexto;
import java.io.*;
/**
 *
 * @author Alma LHO
 */
public class CapturaTexto {
    
    public static String Leer_Archivo(File archivo){
        String texto = "";
        try {
            BufferedReader almacenamiento = new BufferedReader(new FileReader(archivo));
            String contenido;
            while ((contenido = almacenamiento.readLine()) != null) {
                texto += (contenido + "\n"); 
            }
        } catch (IOException ex) {
            ex.getMessage();
        }
        return texto;
    }

    public static void Guardar_Archivo(File archivo, String texto) {
        try {
            FileWriter contenido = new FileWriter(archivo);
            PrintWriter escribir = new PrintWriter(new BufferedWriter(contenido));
            escribir.println(texto);
            escribir.flush();
            if (null != escribir) {
                contenido.close();
            }
        } catch (IOException ex) {
            ex.getMessage();
        }
    }
}