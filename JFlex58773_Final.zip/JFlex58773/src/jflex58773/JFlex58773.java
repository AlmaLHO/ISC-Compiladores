package jflex58773;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class JFlex58773 {

    public static void main(String[] args) throws Exception {
        try {
            generarLexer();
        } catch (Exception e) {
            throw new Exception("Error al generar Archivo Lexer");
        }
    }

    public static void generarLexer() throws Exception {
        // Ruta del archivo donde se encuentra el archivo lex.flex
        String[] ruta = {"C://Users//Alma LHO//Documents//ApacheNetBeansProjects//JFlex58773//src//jflex58773//lex.flex"};
        try {
            jflex.Main.generate(ruta);

            String[] ruta1 = {ruta + "/src/jflx58773/Lex.flex"};
            String[] ruta2 = {ruta + "/src/jflx58773/LexerCup.flex"};
            String[] rutaS = {"-parser", "Sintax", ruta + "/src/jflx58773/Sintax.cup"};

            jflex.Main.generate(ruta1);
            jflex.Main.generate(ruta2);
            jflex.Main.main(rutaS);

            Path rutaSym = Paths.get(ruta + "/src/domain/sym.java");
            if (Files.exists(rutaSym)) {
                Files.delete(rutaSym);
            }
            Files.move(
                    Paths.get(ruta + "/sym.java"),
                    Paths.get(ruta + "/src/jflx58773/sym.java")
            );
            Path rutaSin = Paths.get(ruta + "/src/jflx58773/Sintax.java");
            if (Files.exists(rutaSin)) {
                Files.delete(rutaSin);
            }
            Files.move(
                    Paths.get(ruta + "/Sintax.java"),
                    Paths.get(ruta + "/src/jflx58773/Sintax.java")
            );

        } catch (Exception e) {
            throw new Exception("Error al crear  Archivo Lexer.java ");
        }

    }
}
